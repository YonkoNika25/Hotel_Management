-- 1. Danh sách tất cả các khách sạn với số lượng phòng
SELECT H.Name AS HotelName, COUNT(R.RoomID) AS RoomCount
FROM Hotel H
LEFT JOIN Room R ON H.HotelID = R.HotelID
GROUP BY H.HotelID;

-- 2. Tìm tất cả các phòng đôi 
SELECT RoomNumber, RoomType, Price 
FROM Room 
WHERE RoomType = 'Single' ;

-- 3. Tổng doanh thu từ tất cả các hóa đơn
SELECT SUM(TotalAmount) AS TotalRevenue 
FROM Invoice;

-- 4. Danh sách các khách hàng đã đặt phòng
SELECT DISTINCT C.Name AS CustomerName, C.Phone
FROM Customer C
JOIN Booking B ON C.CustomerID = B.CustomerID;

-- 5. Dịch vụ nào được sử dụng nhiều nhất
SELECT S.Name AS ServiceName, SUM(SB.Quantity) AS TotalUsage
FROM Service S
JOIN ServiceBooking SB ON S.ServiceID = SB.ServiceID
GROUP BY S.ServiceID
ORDER BY TotalUsage DESC
LIMIT 1;