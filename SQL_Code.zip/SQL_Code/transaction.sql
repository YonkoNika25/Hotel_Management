-- 1. Thêm đơn đặt phòng và hóa đơn, rollback nếu có lỗi
START TRANSACTION;
INSERT INTO Booking (BookingID, CheckInDate, CheckOutDate, Status, CustomerID, RoomID, StaffID) 
VALUES (8,'2024-12-15', '2024-12-20', 'Confirmed', 1, 2, 4);

INSERT INTO Invoice (BookingID, TotalAmount, PaymentStatus) 
VALUES (8, 500.00, 'Unpaid');

ROLLBACK; -- Hoàn tác nếu có lỗi

-- 2. Thêm phản hồi từ khách hàng
START TRANSACTION;
INSERT INTO Feedback (Rating, Comments, Date, CustomerID, BookingID) 
VALUES (5, 'Excellent service!', '2024-12-12', 3, 2);

COMMIT; -- Lưu thay đổi

-- 3. Thêm dịch vụ và khuyến mãi
START TRANSACTION;
INSERT INTO Service (Name, Price) VALUES ('Spa', 50.00);
INSERT INTO Promotion (Name, DiscountRate, StartDate, EndDate) 
VALUES ('Holiday Sale', 10, '2024-12-01', '2024-12-31');

COMMIT;