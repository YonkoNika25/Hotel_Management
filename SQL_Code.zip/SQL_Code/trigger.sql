DELIMITER //

-- Trigger: Tự động cập nhật trạng thái phòng khi có đơn đặt phòng
CREATE TRIGGER UpdateRoomStatusAfterBooking
AFTER INSERT ON Booking
FOR EACH ROW
BEGIN
    UPDATE Room
    SET Status = 'Occupied'
    WHERE RoomID = NEW.RoomID;
END;
DELIMITER ;

DELIMITER //
-- Trigger: Gửi thông báo khi có phản hồi mới
CREATE TRIGGER NotifyFeedback
AFTER INSERT ON Feedback
FOR EACH ROW
BEGIN
    INSERT INTO Notifications (Message, Date)
    VALUES (CONCAT('New feedback received from CustomerID: ', NEW.CustomerID), NOW());
END;
DELIMITER ;
