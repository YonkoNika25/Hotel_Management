DELIMITER //

-- Procedure: Tính tổng doanh thu theo khách sạn
CREATE PROCEDURE GetHotelRevenue(IN hotelID INT)
BEGIN
    SELECT SUM(I.TotalAmount) AS TotalRevenue
    FROM Invoice I
    JOIN Booking B ON I.BookingID = B.BookingID
    JOIN Room R ON B.RoomID = R.RoomID
    WHERE R.HotelID = hotelID;
END;
DELIMITER ;
