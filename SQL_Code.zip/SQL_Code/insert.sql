-- Insert data into 'hotel'
INSERT INTO hotel (HotelID, Name, Address, Phone, StarRating) VALUES
(1, 'Grand Palace', '123 Main St', '1234567890', 5),
(2, 'City Inn', '456 Market Ave', '9876543210', 4),
(3, 'Seaside Resort', '789 Beach Blvd', '1122334455', 5),
(4, 'Mountain Retreat', '321 Hilltop Rd', '2233445566', 4),
(5, 'Urban Stay', '654 Urban Ln', '3344556677', 3),
(6, 'Lakeside Hotel', '987 Lakeview Dr', '4455667788', 4),
(7, 'Budget Motel', '123 Budget St', '5566778899', 2);

-- Insert data into 'room'
INSERT INTO room (RoomID, RoomNumber, RoomType, Price, HotelID) VALUES
(1, '101', 'Single', 100.00, 1),
(2, '102', 'Double', 150.00, 1),
(3, '201', 'Suite', 250.00, 2),
(4, '202', 'Single', 90.00, 2),
(5, '301', 'Double', 140.00, 3),
(6, '302', 'Suite', 300.00, 3),
(7, '401', 'Single', 80.00, 4);

-- Insert data into 'customer'
INSERT INTO customer (CustomerID, Name, Phone, Email, Address, CreditCardInfo) VALUES
(1, 'John Doe', '5551234567', 'john.doe@example.com', '100 Elm St', '1234-5678-9012-3456'),
(2, 'Jane Smith', '5559876543', 'jane.smith@example.com', '200 Oak St', '2345-6789-0123-4567'),
(3, 'Alice Brown', '5555555555', 'alice.brown@example.com', '300 Pine St', '3456-7890-1234-5678'),
(4, 'Bob Johnson', '5554444444', 'bob.johnson@example.com', '400 Maple St', '4567-8901-2345-6789'),
(5, 'Charlie White', '5553333333', 'charlie.white@example.com', '500 Birch St', '5678-9012-3456-7890'),
(6, 'Diana Green', '5552222222', 'diana.green@example.com', '600 Cedar St', '6789-0123-4567-8901'),
(7, 'Ethan Black', '5551111111', 'ethan.black@example.com', '700 Spruce St', '7890-1234-5678-9012');

-- Insert data into 'staff'
INSERT INTO staff (StaffID, Name, Phone, Position, HotelID) VALUES
(1, 'Emily Turner', '5556667777', 'Manager', 1),
(2, 'Frank Walker', '5559998888', 'Receptionist', 1),
(3, 'Grace Hall', '5550001111', 'Housekeeper', 2),
(4, 'Harry Adams', '5552223333', 'Chef', 3),
(5, 'Ivy Lee', '5554445555', 'Receptionist', 4),
(6, 'Jack Wilson', '5556660000', 'Manager', 5),
(7, 'Karen Young', '5557778888', 'Security', 6);

-- Insert data into 'booking'
INSERT INTO booking (BookingID, CheckInDate, CheckOutDate, Status, CustomerID, RoomID, StaffID) VALUES
(1, '2024-01-01', '2024-01-05', 'Confirmed', 1, 1, 1),
(2, '2024-02-10', '2024-02-15', 'Checked In', 2, 2, 2),
(3, '2024-03-20', '2024-03-25', 'Cancelled', 3, 3, 3),
(4, '2024-04-01', '2024-04-10', 'Confirmed', 4, 4, 4),
(5, '2024-05-15', '2024-05-20', 'Checked Out', 5, 5, 5),
(6, '2024-06-01', '2024-06-05', 'Confirmed', 6, 6, 6),
(7, '2024-07-01', '2024-07-10', 'Confirmed', 7, 7, 7);

-- Insert data into 'invoice'
INSERT INTO invoice (InvoiceID, BookingID, TotalAmount, PaymentStatus) VALUES
(1, 1, 500.00, 'Paid'),
(2, 2, 750.00, 'Pending'),
(3, 3, 0.00, 'Cancelled'),
(4, 4, 900.00, 'Paid'),
(5, 5, 700.00, 'Paid'),
(6, 6, 1500.00, 'Pending'),
(7, 7, 800.00, 'Paid');

-- Insert data into 'supplier'
INSERT INTO supplier (SupplierID, Name, ContactInfo, ServiceType) VALUES
(1, 'Food Supply Co', '5558889999', 'Catering'),
(2, 'Cleaners Inc.', '5557776666', 'Cleaning'),
(3, 'Tech Solutions', '5551231234', 'IT Support'),
(4, 'Security Services', '5554564567', 'Security'),
(5, 'Furniture Supply', '5557897890', 'Furniture'),
(6, 'Laundry Services', '5553213210', 'Laundry'),
(7, 'Gardening Experts', '5556546543', 'Gardening');



-- Insert data into 'servicebooking'
INSERT INTO servicebooking (ServiceBookingID, BookingID, ServiceID, Quantity, PromotionID) VALUES
(1, 1, 1, 2, 1),
(2, 2, 2, 1, 2),
(3, 3, 3, 3, 3),
(4, 4, 4, 1, NULL),
(5, 5, 5, 2, 4),
(6, 6, 6, 1, NULL),
(7, 7, 7, 1, 5);

-- Insert data into 'service'
INSERT INTO service (ServiceID, Name, Price, SupplierID) VALUES
(1, 'Room Cleaning', 50.00, 1),
(2, 'Breakfast Buffet', 20.00, 7),
(3, 'Wi-Fi', 10.00, 2),
(4, 'Pool Access', 30.00, 3),
(5, 'Gym Access', 25.00, 4),
(6, 'Spa', 100.00, 5),
(7, 'Parking', 15.00, 6);

-- Insert data into 'promotion'
INSERT INTO promotion (PromotionID, Name, DiscountRate, StartDate, EndDate) VALUES
(1, 'Summer Discount', 0.10, '2024-06-01', '2024-08-31'),
(2, 'Holiday Special', 0.15, '2024-12-01', '2024-12-31'),
(3, 'Weekend Saver', 0.05, '2024-01-01', '2024-12-31'),
(4, 'Early Bird', 0.20, '2024-03-01', '2024-05-31'),
(5, 'Loyalty Discount', 0.10, '2024-01-01', '2024-12-31'),
(6, 'Flash Sale', 0.25, '2024-07-01', '2024-07-07'),
(7, 'Midweek Deal', 0.08, '2024-01-01', '2024-12-31');

-- Insert data into 'feedback'
INSERT INTO feedback (FeedbackID, Rating, Comments, Date, CustomerID, BookingID) VALUES
(1, 5, 'Excellent service!', '2024-01-06', 1, 1),
(2, 4, 'Very good stay!', '2024-02-16', 2, 5),
(3, 4, 'Very good stay!', '2024-01-20', 3, 2),
(4, 3, 'Good!', '2024-02-5', 4, 3),
(5, 5, 'Very good!', '2024-02-11', 5, 4);
