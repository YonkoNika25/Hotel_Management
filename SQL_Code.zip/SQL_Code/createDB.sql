-- Tạo cơ sở dữ liệu
CREATE DATABASE HotelManagement;

-- Sử dụng cơ sở dữ liệu
USE HotelManagement;

-- Tạo bảng Hotel
CREATE TABLE Hotel (
    HotelID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Address VARCHAR(255),
    Phone VARCHAR(15),
    StarRating INT
);

-- Tạo bảng Room
CREATE TABLE Room (
    RoomID INT PRIMARY KEY AUTO_INCREMENT,
    RoomNumber VARCHAR(10) NOT NULL,
    RoomType VARCHAR(50),
    Price DECIMAL(10, 2),
    Status VARCHAR(50),
    HotelID INT,
    FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID)
);

-- Tạo bảng Customer
CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Phone VARCHAR(15),
    Email VARCHAR(255),
    Address VARCHAR(255),
    CreditCardInfo VARCHAR(50)
);

-- Tạo bảng Booking
CREATE TABLE Booking (
    BookingID INT PRIMARY KEY AUTO_INCREMENT,
    CheckInDate DATE,
    CheckOutDate DATE,
    Status VARCHAR(50),
    CustomerID INT,
    RoomID INT,
    StaffID INT, -- Mối quan hệ với Staff
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (RoomID) REFERENCES Room(RoomID),
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID)
);

-- Tạo bảng Invoice
CREATE TABLE Invoice (
    InvoiceID INT PRIMARY KEY AUTO_INCREMENT,
    BookingID INT,
    TotalAmount DECIMAL(10, 2),
    PaymentStatus VARCHAR(50),
    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);
ALTER TABLE invoice MODIFY PaymentStatus VARCHAR(10);


-- Tạo bảng Staff
CREATE TABLE Staff (
    StaffID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Phone VARCHAR(15),
    Position VARCHAR(50),
    HotelID INT,
    FOREIGN KEY (HotelID) REFERENCES Hotel(HotelID)
);

-- Tạo bảng Service
CREATE TABLE Service (
    ServiceID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Price DECIMAL(10, 2),
    SupplierID INT, -- Mối quan hệ với Supplier
    FOREIGN KEY (SupplierID) REFERENCES Supplier(SupplierID)
);

-- Tạo bảng Supplier
CREATE TABLE Supplier (
    SupplierID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    ContactInfo VARCHAR(255),
    ServiceType VARCHAR(50)
);

-- Tạo bảng Promotion
CREATE TABLE Promotion (
    PromotionID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255),
    DiscountRate DECIMAL(5, 2),
    StartDate DATE,
    EndDate DATE
);

-- Tạo bảng ServiceBooking
CREATE TABLE ServiceBooking (
    ServiceBookingID INT PRIMARY KEY AUTO_INCREMENT,
    BookingID INT,
    ServiceID INT,
    Quantity INT,
    PromotionID INT, -- Mối quan hệ với Promotion
    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID),
    FOREIGN KEY (ServiceID) REFERENCES Service(ServiceID),
    FOREIGN KEY (PromotionID) REFERENCES Promotion(PromotionID)
);

-- Tạo bảng Feedback
CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY AUTO_INCREMENT,
    Rating INT,
    Comments TEXT,
    Date DATE,
    CustomerID INT,
    BookingID INT,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
    FOREIGN KEY (BookingID) REFERENCES Booking(BookingID)
);
