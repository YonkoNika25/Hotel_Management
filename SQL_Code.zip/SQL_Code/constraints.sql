-- Đảm bảo số điện thoại khách hàng là duy nhất
ALTER TABLE Customer ADD CONSTRAINT Unique_Phone UNIQUE (Phone);

-- Đảm bảo số phòng trong mỗi khách sạn không trùng lặp
ALTER TABLE Room ADD CONSTRAINT Unique_Room UNIQUE (HotelID, RoomNumber);

-- Đảm bảo trạng thái thanh toán chỉ nhận các giá trị hợp lệ
ALTER TABLE Invoice MODIFY PaymentStatus ENUM('Paid', 'Unpaid', 'Refunded');